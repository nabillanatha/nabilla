<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GuruSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::Table('guru')->insert([
            'NIP' => '111',
            'Nama Guru' => 'Pak Asep',
            'Alamat' => 'Tanjung',
            'Tanggal Lahir' => '1985-08-19',
        ]);

        DB::Table('guru')->insert([
            'NIP' => '112',
            'Nama Guru' => 'Pak Andri',
            'Alamat' => 'Pamoyanan',
            'Tanggal Lahir' => '1995-08-03',
        ]);

        DB::Table('guru')->insert([
            'NIP' => '113',
            'Nama Guru' => 'Ibu Revy',
            'Alamat' => 'Leles',
            'Tanggal Lahir' => '1998-05-05',
        ]);

        DB::Table('guru')->insert([
            'NIP' => '114',
            'Nama Guru' => 'Pak Asep',
            'Alamat' => 'Leles',
            'Tanggal Lahir' => '1996-03-26',
        ]);
    }
}
